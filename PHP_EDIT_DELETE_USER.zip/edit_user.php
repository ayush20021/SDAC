<?php
$host = "localhost";
$id = "root";
$pass = "";
$db = "employees";
$conn = mysqli_connect($host, $id, $pass, $db);
$user_id = $_GET['id'];
$query = "SELECT * FROM `empinfo` WHERE `ID` = $user_id";
$data = mysqli_query($conn, $query);
$res = mysqli_fetch_assoc($data);
?>
<!doctype html>
<html lang="en">
<head>
    <title>Title</title>
    <!-- Required meta tags -->
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />

    <!-- Bootstrap CSS v5.2.1 -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous" />
</head>

<body>
    <header>
        <!-- place navbar here -->
    </header>
    <main>

    <h4 class ="text-center mt-4">Edit User Details </h4>
        <div class="container allign-items-center w-50 mt-3">
            <form action="edit.php" method="post">
            <div class="mb-3">
                <input
                type="hidden"
                    type="text"
                    class="form-control"
                    name="uid"
                    id=""
                    aria-describedby="helpId"
                    placeholder=""
                    value="<?php echo"{$res['ID']}"?>"
                />
            </div>
            <div class="mb-3">
                <label for="" class="form-label">Name</label>
                <input
                    type="text"
                    class="form-control"
                    name="uname"
                    id=""
                    value="<?php echo"{$res['Name']}"?>"
                />
            </div>
            <div class="mb-3">
                <label for="" class="form-label">Email</label>
                <input
                    type="email"
                    class="form-control"
                    name="uemail"
                    id=""
                    aria-describedby="emailHelpId"
                    placeholder="abc@mail.com"
                    value="<?php echo"{$res['Email']}"?>"
                />
            </div>
            <div class="mb-3">
                <label for="" class="form-label">Password</label>
                <input
                    type="password"
                    class="form-control"
                    name="upass"
                    id=""
                    placeholder=""
                    value="<?php echo"{$res['Password']}"?>"
                />
            </div>
                <button
                    type="submit"
                    class="btn btn-primary"
                >
                    Edit
                </button>
            </form>
        </div>
    </main>
    <footer>
        <!-- place footer here -->
    </footer>
    <!-- Bootstrap JavaScript Libraries -->
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.8/dist/umd/popper.min.js" integrity="sha384-I7E8VVD/ismYTF4hNIPjVp/Zjvgyol6VFvRkX/vR+Vc4jQkC+hVqc2pM8ODewa9r" crossorigin="anonymous"></script>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.min.js" integrity="sha384-BBtl+eGJRgqQAUMxJ7pMwbEyER4l1g+O15P+16Ep7Q9Q+zqX6gSbd85u4mG4QzX+" crossorigin="anonymous"></script>
</body>

</html>