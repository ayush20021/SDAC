<?php 
$host = "localhost";
$id="root";
$pass="";
$db="employees";


$u_Name=$_POST["uname"];
$u_Pass=$_POST["upass"];

echo  $u_Name;
echo $u_Pass;
$conn = mysqli_connect($host,$id,$pass,$db);

$query = "SELECT * FROM `empinfo` WHERE `Name`='$u_Name'AND`Password`='$u_Pass';";

$status = mysqli_query($conn,$query);

if(mysqli_num_rows($status)>0){
    header("Location:Home.php");
}else{

    header("Location:Error.html");
}





?>