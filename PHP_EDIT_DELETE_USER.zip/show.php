<?php 


$host = "localhost";
$id="root";
$pass="";
$db="employees";
$conn = mysqli_connect($host,$id,$pass,$db);
$sql="Select * from empinfo";

$info = mysqli_query($conn,$sql);


while($data = mysqli_fetch_array($info)){
 
    echo " EMP ID  :".$data['ID']."<br>";
    echo " EMP Name: ".$data['Name']."<br>";
    echo " EMP Email  :".$data['Email']."<br>";
    echo "--------------------------------------- <br>";


}




?>