<?php 
$host = "localhost";
$id="root";
$pass="";
$db="employees";


$u_Name=$_POST["uname"];
$u_Email=$_POST['uemail'];
$u_Pass=$_POST["upass"];

$conn = mysqli_connect($host,$id,$pass,$db);

$query = "INSERT INTO `empinfo` (`ID`, `Name`, `Email`, `Password`) VALUES (NULL, '$u_Name', '$u_Email', '$u_Pass')";

$status = mysqli_query($conn,$query);

if($status){
    header("Location:Login.html");
}else{

    header("Location:ERR.html");
}





?>