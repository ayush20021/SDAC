<?php 
$host = "localhost";
$id="root";
$pass="";
$db="employees";
$user_id = $_POST['uid'];
echo$user_id;
$u_name= $_POST['uname'];
echo$u_name;
 $u_email= $_POST['uemail'];
 $u_password= $_POST['upass'];
$conn = mysqli_connect($host,$id,$pass,$db);
$query="UPDATE `empinfo` SET `Name`='$u_name',`Email`='$u_email',`Password`='$u_password' WHERE `ID`=$user_id";
if(mysqli_query($conn, $query)){
    header("Location:Home.php");
    
}else{
    echo"ERR";
}







?>