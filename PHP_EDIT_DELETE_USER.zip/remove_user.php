<?php 
$uid = $_GET['id'];
$host = "localhost";
$id="root";
$pass="";
$db="employees";
$conn = mysqli_connect($host,$id,$pass,$db);
$sql="DELETE FROM empinfo WHERE `empinfo`.`ID` = $uid";


if(mysqli_query($conn,$sql)){

    header("LOcation:Home.php");

}else{
    echo "ERROR OCCURED";
}








?>